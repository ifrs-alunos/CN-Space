from django.contrib import admin
from .models.cadastro import Cadastro

# Register your models here.

admin.site.register(Cadastro)

