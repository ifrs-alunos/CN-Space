from django.apps import AppConfig


class DesenhoConfig(AppConfig):
    name = 'desenho'
