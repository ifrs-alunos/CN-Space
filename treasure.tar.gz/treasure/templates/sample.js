$(function(){
	M.AutoInit();
});

$(".dropdown-trigger").dropdown();