from .base import *
from .person import *
from .passport import *
from .reporter import *
from .article import *
from .magazine import *