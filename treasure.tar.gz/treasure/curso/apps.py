from django.apps import AppConfig


class CursoConfig(AppConfig):
    name = 'curso'
