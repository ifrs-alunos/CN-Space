from .base import *
from .comentario import *
from .tag import *
from .postagem import *